import { mxSwap } from "../src/mxApi";

// ts-node test/getSwap.ts

mxSwap("SOLUSDT", "BUY", '0.01');
