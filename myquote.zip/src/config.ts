export const minRange = 0.35;
export const maxRange = 0.9;
export const trAmount = '0.1';
export const API_KEY = "kwrk-mx0vglcoBQflOdr3jZ";
export const API_SECRET = "fa3327bd4d76480e96395b96632651da";
export const BASE_URL = "http://api.mexc.com";